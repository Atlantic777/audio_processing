package com.example.audioprocessing;

import java.io.IOException;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Looper;
import android.os.PowerManager;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ActionBar.LayoutParams;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint({ "ShowToast", "NewApi" })
public class MainActivity extends Activity {
	 
	Thread t;
	Thread ti;
	static {
	    	System.loadLibrary("audio-jni");
	    }
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Toast toast =  Toast.makeText(getBaseContext(), "Processing done ", 1);
        final Dialog dialogFir =new Dialog(this);
        dialogFir.setTitle(" FIR Processing");
        final Dialog dialogIir =new Dialog(this);
        final RadioButton radioButton = (RadioButton) findViewById(R.id.radioButton1);
        dialogIir.setTitle(" IIR Processing");              
        Button fir = (Button) findViewById(R.id.button1);
        Button iir = (Button) findViewById(R.id.button2);
        fir.setOnClickListener(new OnClickListener() {
        	
			@Override
			public void onClick(View v) {
				dialogFir.setContentView(R.layout.dialog);
			    dialogFir.setCanceledOnTouchOutside(false);
				dialogFir.show();
			    t = new Thread (new Runnable () {
					@Override
					public void run() {						
						audioProcessingJNI(0);
						 MediaPlayer mp = new MediaPlayer();
					        try {
									mp.setDataSource("/sdcard/outFir.wav");
							} catch (IllegalArgumentException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (SecurityException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IllegalStateException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					        try {
								mp.prepare();
							} catch (IllegalStateException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					        dialogFir.cancel();					        
					        toast.show();
					        if(radioButton.isActivated()) {
					        	mp.start();
					}       }
				});
				t.start();
			}
		});
        
        iir.setOnClickListener(new OnClickListener() {
        	
			@Override
			public void onClick(View v) {
				dialogIir.setContentView(R.layout.dialog);
				dialogIir.setCanceledOnTouchOutside(false);
				dialogIir.show();				
			     ti = new Thread (new Runnable () {
					@Override
					public void run() {						
						audioProcessingJNI(1);
						 MediaPlayer mp = new MediaPlayer();
					        try {
									mp.setDataSource("/sdcard/outIir.wav");
							} catch (IllegalArgumentException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (SecurityException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IllegalStateException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					        try {
								mp.prepare();
							} catch (IllegalStateException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					        dialogIir.cancel();					     
					        toast.show();
					        mp.start();						        
					}
				});
				ti.start();
			}
		});
    }
    //1 - fir; 2-iir
    public static native void audioProcessingJNI(int choice);
   
    @SuppressWarnings("deprecation")
	@Override
    public void onBackPressed() {
    	// TODO Auto-generated method stub
    	super.onBackPressed();
    	t.interrupt();
    	ti.interrupt();    				    
    }
}
