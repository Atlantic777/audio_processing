/*
 * processing.c

 *
 *  Created on: Apr 24, 2013
 *      Author: Strahinja Petrovic
 */

#include "processing.h"
#include "const.h"
#include <stdio.h>
#include "readFile.h"




extern double sampleBuffer[][BLOCK_SIZE];
extern double sampleBufferFir[][BLOCK_SIZE];
extern double sampleBufferIir[][BLOCK_SIZE];
double historyBufferL[COEF_NUM_IIR];
double historyBufferR[COEF_NUM_IIR];
double coeffA[COEF_NUM_IIR ];
double coeffB[COEF_NUM_IIR];
double coeff[COEF_NUM];
double circularBufferIIRL[COEF_NUM_IIR];
double circularBufferIIRR[COEF_NUM_IIR];
double circularBufferL[COEF_NUM];
double circularBufferR[COEF_NUM];
int readLFir = 0;
int readRFir = 0;
int readLIir = 0;
int readRIir = 0;

void initCoef()
{
	readCoefs(coeffA,coeffB,coeff);  // read coefficients for FIR and IIR filter from file
}

void audio_processing(int choice)
{

	double left_sample;
	double right_sample;
	int i;


	for(i=0;i<BLOCK_SIZE;i++)
	{

		left_sample = sampleBuffer[0][i]; 			// 0. row - left channel
		right_sample = sampleBuffer[1][i]; 			// 1. row - right channel

		if(choice == 0) {
			sampleBufferFir[0][i] = fir_filter(left_sample,circularBufferL,&readLFir);
			sampleBufferFir[1][i] = fir_filter(right_sample,circularBufferR,&readRFir);
		}else if(choice ==1) {
			sampleBufferIir[0][i] = iir_filter(left_sample,circularBufferIIRL,historyBufferL,&readLIir);
			sampleBufferIir[1][i] = iir_filter(right_sample,circularBufferIIRR,historyBufferR,&readRIir);
		}
	}

}

double fir_filter(double sample,double *circularBuffer,int *read)
{
	int i;
	double ret = 0;
	circularBuffer[(*read)] = sample;


	for(i=0;i<COEF_NUM;i++,*read = (*read -1))
	{
		if(*(read) < 0)
		{
			(*read) = COEF_NUM-1;
		}
				ret += circularBuffer[(*read)]*coeff[i];
	}

		(*read) = (*read) +1 ;
		return ret;

}



double iir_filter(double sample, double *circularBuffer, double *historyBuffer, int *read)
{

		int i;
		int j;
		int readH;
		double ret = 0;
		double back = 0;
		double output;

		circularBuffer[(*read)] = sample;		// get current sample
		readH = *read -1;							// set pointer on y[n-1]


			for(i=0;i<COEF_NUM_IIR;i++,*read = (*read -1))     //	fir part
			{

				if(*(read) < 0)
				{
					(*read) = COEF_NUM_IIR-1;
				}

				ret += circularBuffer[(*read)]*coeffB[i];

			}


			for(j=1;j<COEF_NUM_IIR;j++,readH--)   //	feedback
			{

				if(readH < 0)
				{
					readH = COEF_NUM_IIR -1 ;
				}

				back += historyBuffer[readH]*coeffA[j];

			}

			if((*read) < 0)						//control circular buffer
				*read = COEF_NUM_IIR-1;

			output = (ret - back)/coeffA[0];  	//    1/a0*(fir - feedback)
			historyBuffer[*read] = output;		//	save history for next iteration
			(*read) = (*read) +1 ; 					//	go to next sample from input signal

			if(*read == COEF_NUM_IIR)
				*read = 0;

			return output;

}



