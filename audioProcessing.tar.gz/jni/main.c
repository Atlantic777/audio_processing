
#include <stdlib.h>
#include <string.h>
#include "const.h"
#include "WAVheader.h"
#include "processing.h"
#include <jni.h>

double sampleBuffer[MAX_NUM_CHANNEL][BLOCK_SIZE];
double sampleBufferFir[MAX_NUM_CHANNEL][BLOCK_SIZE];
double sampleBufferIir[MAX_NUM_CHANNEL][BLOCK_SIZE];

WAV_HEADER inWAVhdr,outputWAVhdr;

void Java_com_example_audioprocessing_MainActivity_audioProcessingJNI(JNIEnv* env,jobject thiz,
        jint choice)
{
	FILE *wav_in=NULL;
	FILE *wav_outFir=NULL;
	FILE *wav_outIir = NULL;
	char WavInputName[256];
	char WavOutputNameFir[256];
	char WavOutputNameIir[256];
	int i;
	int j;
	int k;


	// Init channel buffers
	for( i=0; i<MAX_NUM_CHANNEL; i++)
		memset(&sampleBuffer[i],0,BLOCK_SIZE);

	// Open input and output wav files
	//-------------------------------------------------
	strcpy(WavInputName,"/sdcard/Freq_sweep.wav");			//write name of input signal
	wav_in = OpenWavFileForRead (WavInputName,"rb");

	strcpy(WavOutputNameFir,"/sdcard/outFir.wav");
	wav_outFir = OpenWavFileForRead (WavOutputNameFir,"wb");

	strcpy(WavOutputNameIir,"/sdcard/outIir.wav");
	wav_outIir = OpenWavFileForRead (WavOutputNameIir,"wb");


	//-------------------------------------------------

	// Read input wav header
	//-------------------------------------------------
	ReadWavHeader(wav_in);
	//-------------------------------------------------

	// Write wav header to output file
	//-------------------------------------------------
	outputWAVhdr = inWAVhdr;

	// If number of output channle is changed
	//-------------------------------------------------
	outputWAVhdr.fmt.NumChannels = inWAVhdr.fmt.NumChannels; // change number of channels

	int oneChannelSubChunk2Size = inWAVhdr.data.SubChunk2Size/inWAVhdr.fmt.NumChannels;
	int oneChannelByteRate = inWAVhdr.fmt.ByteRate/inWAVhdr.fmt.NumChannels;
	int oneChannelBlockAlign = inWAVhdr.fmt.BlockAlign/inWAVhdr.fmt.NumChannels;

	printf("\n Audio format  %d",inWAVhdr.fmt.AudioFormat);
	printf("\n Num Channels %d ",inWAVhdr.fmt.NumChannels);
	printf("\n Bits per sample %d",inWAVhdr.fmt.BitsPerSample);
	printf("\n Sample rate %d",inWAVhdr.fmt.SampleRate);
	printf("\n BLOCK_SIZE %d\n",BLOCK_SIZE);

	outputWAVhdr.data.SubChunk2Size = oneChannelSubChunk2Size*outputWAVhdr.fmt.NumChannels;
	outputWAVhdr.fmt.ByteRate = oneChannelByteRate*outputWAVhdr.fmt.NumChannels;
	outputWAVhdr.fmt.BlockAlign = oneChannelBlockAlign*outputWAVhdr.fmt.NumChannels;

	WriteWavHeader(wav_outFir);
	WriteWavHeader(wav_outIir);

     initCoef();			// get coefficients for FIR and IIR filters

	// Processing loop
	//-------------------------------------------------


	{
		int sample;
		int BytesPerSample = inWAVhdr.fmt.BitsPerSample/8;
		const double SAMPLE_SCALE = -(double)(1 << 31);		//2^31
		int iNumSamples = inWAVhdr.data.SubChunk2Size/(inWAVhdr.fmt.NumChannels*inWAVhdr.fmt.BitsPerSample/8);

		int iterNum;
		int diff=0;
		int BLOCK_SIZE_t;

		if(iNumSamples % BLOCK_SIZE == 0) 		// Verify that the file length is a multiple of BLOCK_SIZE
		{
			iterNum = iNumSamples/BLOCK_SIZE;
			BLOCK_SIZE_t = BLOCK_SIZE;

		}
		else
		{
			iterNum = iNumSamples/BLOCK_SIZE+1;
			diff = iNumSamples % BLOCK_SIZE;
			printf("\nDifference between block and file is %d\n",diff);

		}

		// exact file length should be handled correctly...
		for( i=0; i<iterNum; i++)
		{
			if(i == iterNum -1 && diff != 0)
			{
				BLOCK_SIZE_t = diff;
			}
			for( j=0; j<BLOCK_SIZE_t; j++)
			{
				for( k=0; k<inWAVhdr.fmt.NumChannels; k++)
				{
					sample = 0;
					fread(&sample, BytesPerSample, 1, wav_in);
					sample = sample << (32 - inWAVhdr.fmt.BitsPerSample);
					sampleBuffer[k][j] = (double)sample / SAMPLE_SCALE;			// scale sample to 1.0/-1.0 range

				}
			}


			audio_processing(choice); 												// call audio processing for BLOCK_SIZE samples !


			for( j=0; j<BLOCK_SIZE_t; j++)
			{
				for( k=0; k<outputWAVhdr.fmt.NumChannels; k++)
				{
					if(choice == 0) {
						sample = sampleBufferFir[k][j] *SAMPLE_SCALE ;				// crude, non-rounding
						sample = sample >> (32 - inWAVhdr.fmt.BitsPerSample);
						fwrite(&sample, inWAVhdr.fmt.BitsPerSample/8, 1, wav_outFir);  //write in wav file FIR
					}else if(choice == 1) {
						sample = sampleBufferIir[k][j] *SAMPLE_SCALE;
						sample = sample >> (32 - inWAVhdr.fmt.BitsPerSample);
						fwrite(&sample, outputWAVhdr.fmt.BitsPerSample/8, 1, wav_outIir); // write in wav file IIR

					}

				}
			}

		}
	}

	// Close files
		//-------------------------------------------------
		fclose(wav_in);
		fclose(wav_outFir);
		fclose(wav_outIir);


}

