/*
 * const.h
 *
 *  Created on: Apr 25, 2013
 *      Author: Strahinja
 */

#ifndef CONST_H_
#define CONST_H_
#define FIR
#define DWORD int
#define WORD short
#define true 1
#define BYTE char
#define BLOCK_SIZE 16
#define MAX_NUM_CHANNEL 8
#define COEF_NUM 65
#define COEF_NUM_IIR 5



#endif /* CONST_H_ */
