/*
 * readFile.c
 *
 *  Created on: May 14, 2013
 *      Author: Strahinja Petrovic
 */
#include "readFile.h"
#include <stdio.h>
#include "const.h"
#include <stdlib.h>
#include <string.h>

char coefAName[256];
char coefBName[256];
char coefFIRName[256];
int buffer[10];
FILE *coeffAi = NULL;
FILE *coeffBi = NULL;
FILE *coeffFIR = NULL;

void readCoefs(double *bufferA,double *bufferB,double *bufferFIR)
{
	int i;

	strcpy(coefAName,"/sdcard/coeffA.txt");
	coeffAi = fopen(coefAName,"rb");

	if(coeffAi == NULL)
	{
		printf("Cannot open file %s\n", coefAName);
		exit(1);
	}

	strcpy(coefBName,"/sdcard/coeffB.txt");
	coeffBi = fopen (coefBName,"rb");

	if(coeffBi == NULL)
		{
		printf("Cannot open file %s\n", coefBName);
			exit(1);
		}

	strcpy(coefFIRName,"/sdcard/coeffFIR.txt");
	coeffFIR = fopen (coefFIRName,"rb");

	if(coeffFIR == NULL)
	{
		printf("Cannot open file %s\n", coefFIRName);
		exit(1);
	}


	for(i=0;i<COEF_NUM_IIR;i++)
	{
		fscanf(coeffAi,"%lf",&bufferA[i]);
		fscanf(coeffBi,"%lf",&bufferB[i]);

	}
	for(i =0;i<COEF_NUM;i++)
	{
		fscanf(coeffFIR,"%lf",&bufferFIR[i]);
	}

	fclose (coeffAi);
	fclose (coeffBi);
	fclose (coeffFIR);

}



