/*
 * processing.h
 *
 *  Created on: Apr 24, 2013
 *      Author: vlada
 */

#ifndef PROCESSING_H_
#define PROCESSING_H_
#include "const.h"

void audio_processing(int);
void initCoef();
double fir_filter(double sample,double *circularBuffer,int *read);
double iir_filter(double sample, double *circularBuffer, double *historyBuffer, int *read);



#endif /* PROCESSING_H_ */
