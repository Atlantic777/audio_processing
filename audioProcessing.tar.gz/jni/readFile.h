/*
 * readFile.h
 *
 *  Created on: May 14, 2013
 *      Author: Strahinja
 */

#ifndef READFILE_H_
#define READFILE_H_



void readCoefs(double *bufferA,double *bufferB,double *bufferFIR);


#endif /* READFILE_H_ */
